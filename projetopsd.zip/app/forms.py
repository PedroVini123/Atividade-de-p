from django import forms
from .models import Reportagem


class ReportagemForm(forms.ModelForm):
    class Meta:
        model = Reportagem
        fields = "__all__"
