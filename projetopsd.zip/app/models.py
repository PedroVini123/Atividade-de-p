from django.db import models


# Create your models here.
class Autor(models.Model):
    nome = models.CharField(max_length=100)

    def __str__(self):
        return self.nome


class Tag(models.Model):
    nome = models.CharField(max_length=100)

    def __str__(self):
        return self.nome


class Reportagem(models.Model):
    titulo = models.CharField(max_length=100)
    descricao = models.TextField()
    autor = models.ForeignKey(Autor, on_delete=models.CASCADE)
    data = models.DateField()
    tags = models.ManyToManyField(Tag)
    img = models.ImageField(upload_to="imagens")
    conteudo = models.TextField()
    destacada = models.BooleanField()
    

    def __str__(self):
        return self.titulo
