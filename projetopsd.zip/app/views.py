from django.shortcuts import render, redirect
from .forms import ReportagemForm
from .models import *

# paginação
from django.core.paginator import Paginator

def criar_post(request):
    if request.method == "POST":
        form = ReportagemForm(request.POST, request.FILES)

        if form.is_valid():
            form.save()
            return redirect("index")

    else:
        form = ReportagemForm()

    return render(request, "app/form.html", {"form": form})


"""
Em falta:
- add usuario e adm
    - paginas p cadastro e login
    - 
- ao usuario:
    - editar e excluir reportagem
"""

def index(request):
    tags = Tag.objects.all()
    reportagens = Reportagem.objects.all()


    # Reportagens em destaque (ordem decrescente)    
    reportagens_destaque = Reportagem.objects.filter(destacada=True).order_by("-data")
    reportagens_destaque = reportagens_destaque[:3] # Pega até 3 reportagens

    paginator = Paginator(reportagens, 5)  # Mostra 10 reportagens por página
    page = request.GET.get('page')
    reportagens = paginator.get_page(page)

    # Pega a notícia mais recente
    if reportagens_destaque:
        noticia_destaque_recente = reportagens_destaque[0]
    else:
        noticia_destaque_recente = None

    context = {
        "reportagens": reportagens,
        "tags": tags,
        "noticia_destaque_recente": noticia_destaque_recente,
    }

    return render(request, "app/index.html", context)

